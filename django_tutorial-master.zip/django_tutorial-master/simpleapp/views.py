from django.views.generic import ListView, DetailView
from .models import Article


class ArticleList(ListView):
    model = Article
    template_name = 'articles.html'
    context_object_name = 'news'
    queryset = Article.objects.order_by('-datetime')  # Обратный порядок новостей


class ArticleDetail(DetailView):
    model = Article
    template_name = 'article.html'
    context_object_name = 'article'

